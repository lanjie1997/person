package com.neuedu.omlearn.util;

public class Global {
	//用户角色信息
    public static final String ROLE_TEACHER="TEACHER";
    public static final String ROLE_ADMIN="ADMIN";
    //角色状态信息
    public static final int USER_STATUS_ON=1;
    public static final int USER_STATUS_OFF=0;
    
}
