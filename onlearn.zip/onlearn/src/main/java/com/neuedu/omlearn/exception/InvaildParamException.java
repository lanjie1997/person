package com.neuedu.omlearn.exception;

public class InvaildParamException extends BaseException {
   /**
    * �Զ����û������쳣
    * @param code
    * @param msg
    */
	
	public InvaildParamException(int code,String msg)
	{
		super(code,msg);
	}
}
