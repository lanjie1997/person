package com.neuedu.onlearn.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserController {
 public void test(HttpServletRequest req,HttpServletResponse resp) 
 {
	 System.out.println("test!!!");
 }
}
