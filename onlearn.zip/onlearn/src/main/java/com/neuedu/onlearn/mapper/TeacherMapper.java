package com.neuedu.onlearn.mapper;

import com.neuedu.onlearn.po.Teacher;

public interface TeacherMapper {
	/**
	 * ���ݵ绰�Ų����û�
	 * @param userName
	 * @return
	 */
	Teacher findTeacherByTel(String userName);
		
	/**
	 * ͨ��ID���ҽ�ʦ
	 * @param id
	 * @return
	 */
	Teacher findTeacherById(Integer id);
	/**
	 * ���ӽ�ʦ
	 * @param teacher
	 */
	void addTeacher(Teacher teacher);
	
	/**
	 * �޸Ľ�ʦ��Ϣ
	 * @param teacher
	 */
	void updateTeacher(Teacher teacher);
}
