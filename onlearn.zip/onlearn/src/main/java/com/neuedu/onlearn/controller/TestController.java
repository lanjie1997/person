package com.neuedu.onlearn.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.neuedu.omlearn.exception.InvaildParamException;
import com.neuedu.omlearn.util.E;
import com.neuedu.omlearn.util.SessionManager;

@WebServlet("/teacher/test")
public class TestController extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
	{
		String token=req.getParameter("token");
		if(token == null||token.length()==0)
		{
			throw new InvaildParamException(E.INVAILD_PARAM_ERROR_CODE,E.INVAILD_PARAM_ERROR_INFO);
		}
		HttpSession session=SessionManager.getSession(token);
		if(session==null)
		{
			throw new InvaildParamException(E.INVAILD_PARAM_ERROR_CODE,E.INVAILD_PARAM_ERROR_INFO);
		}
		Object teacher=session.getAttribute("userInfo");
		if(teacher==null)
		{
			throw new InvaildParamException(1003,"���¼");
		}
		resp.getWriter().write(teacher.toString());
	}

}
