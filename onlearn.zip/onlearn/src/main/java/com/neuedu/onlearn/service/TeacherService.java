package com.neuedu.onlearn.service;

import com.neuedu.onlearn.po.Teacher;

public interface TeacherService {
	/**
	 * �û���¼
	 * @param username
	 * @param password
	 */
  
	Teacher login(String username,String password);
	/**
	 * ���ӽ�ʦ
	 * @param teacher
	 */
	void addTeacher(Teacher teacher);
	
	/**
	 *ɾ����ʦ
	 * @param id
	 */
	void deleteTeacher(Integer id);
	/**
	 * �޸Ľ�ʦ��Ϣ
	 * @param teacehr
	 */
	void updateTeacher(Teacher teacehr);
}
