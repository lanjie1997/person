package com.neuedu.onlearn.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neuedu.omlearn.exception.BaseException;
import com.neuedu.omlearn.exception.InvaildParamException;
import com.neuedu.omlearn.util.E;
import com.neuedu.omlearn.util.NameUtil;

/**
 * ����ַ����������ͳһ���
 * @author I
 *
 */
@WebServlet("/*")
public class WebDispatcher extends HttpServlet {
    private static final String PROJECT_NAME="/onlearn/";
    private static final String PACKAGE_NAME="com.neuedu.onlearn.controller";
	private static ObjectMapper objMapper=new ObjectMapper();
	private static Logger log=LogManager.getLogger(WebDispatcher.class);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//��ȡ�û��������ַ
		String uri=req.getRequestURI();
		
		//��¼�û��������������·��
		log.info(req.getRemoteHost()+"�����ַ:"+uri);
		Enumeration<String> paramKeys=req.getParameterNames();
		while(paramKeys.hasMoreElements())
		{
			String key=paramKeys.nextElement();
			log.info("�������"+key+":"+req.getParameter(key));
		}
		
		//ȥ��·���е���Ŀ����
		uri=uri.replace(PROJECT_NAME, "");
	    ApiResult apiResult= new ApiResult();
	    
		try {
			String[] reqUri=uri.split("/");
			if(reqUri.length<2)
			{
				throw new InvaildParamException(E.INVAILD_PARAM_ERROR_CODE,E.INVAILD_PARAM_ERROR_INFO);
				
			}
			//���Ʒ���ת��
			String cat=reqUri[0];
			String opt=reqUri[1];
			cat=NameUtil.convert2Caml(cat);
			cat=NameUtil.firstUpper(cat);
			opt=NameUtil.convert2Caml(opt);
			
			String catName=PACKAGE_NAME+"."+cat+"Controller";
			//��ȡָ���������
			Class<?> clx=Class.forName(catName);
			//��������ʵ��
			Object instance=clx.newInstance();
			//��ȡҪ���õķ���
			Method method=clx.getMethod(opt,HttpServletRequest.class,HttpServletResponse.class);
			Object obj=method.invoke(instance,req,resp);
			if(obj!=null)
			{
				apiResult.setData(obj);
			}
		}
			catch(InvocationTargetException e){
				Throwable targetE=e.getTargetException();
				if(targetE instanceof BaseException)
				{
					BaseException srcException=(BaseException)targetE;
					apiResult.setCode(srcException.getCode());
					apiResult.setMsg(srcException.getMessage());
				}else {
					e.printStackTrace();
					apiResult.setCode(500);
					apiResult.setMsg("�����ڲ�����");
				}
				
	
		}catch(ReflectiveOperationException e){
			e.printStackTrace();
			apiResult.setCode(E.PATH_ERROR_CODE);
			apiResult.setMsg(E.PATH_ERROR_INFO);
		} catch (BaseException e) {
			
			apiResult.setCode(e.getCode());
			apiResult.setMsg(e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
			apiResult.setCode(500);
			apiResult.setMsg("�����ڲ�����");
		}
		String rsStr = objMapper.writeValueAsString(apiResult);
		resp.setCharacterEncoding("utf-8");
		log.info("�����û�����:"+rsStr);
		resp.getWriter().write(rsStr);
		}
		
	
	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
   
} 
