package com.neuedu.onlearn.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.neuedu.omlearn.util.SessionManager;
import com.neuedu.omlearn.util.V;
import com.neuedu.onlearn.po.Teacher;
import com.neuedu.onlearn.service.TeacherService;
import com.neuedu.onlearn.service.TeacherServiceImpl;


public class TeacherController  {
  
  private TeacherService teacherService;
  public TeacherController()
  {
	  this.teacherService=new TeacherServiceImpl();
	  
  }
  /**
   * ��ʦ��¼
   * @param req
   * @param resp
   * @return
   */
public Map<String,String> login(HttpServletRequest req, HttpServletResponse resp)
{
	String[] params= {"login_name","password"};
	V.valid(req, params);
	
  
	
	String username =req.getParameter("login_name");
	String password =req.getParameter("password");
    
	
	//���е�¼����
    Teacher teacher=teacherService.login(username, password);
	
	HttpSession session = req.getSession();
	session.setAttribute("userInfo", teacher);
	//��session��������
    SessionManager.saveSession(session);
	
	//���û���֪��¼�ɹ������ҷ���һ�����ơ�
	
	Map<String,String> map=new HashMap<String,String>();
	map.put("token", session.getId());
	return map;
}
  
/**
 * ���ӽ�ʦ
 * @param req
 * @param resp
 */
  public void add(HttpServletRequest req, HttpServletResponse resp)
  {
	  String[] params = {"tel","password","real_name","title","gender","email","degree","experience"};
	  V.valid(req, params);
	  Teacher teacher=V.entity(req, Teacher.class, params);
	  teacherService.addTeacher(teacher);  
  }
  
  /**
   * ɾ��ָ����Id�Ľ�ʦ
   * @param req
   * @param resp
   */
  public void delete(HttpServletRequest req, HttpServletResponse resp)
  {
	  String[] params= {"id"};
	  V.valid(req, params);
	  int id=Integer.parseInt(req.getParameter("id"));
	  teacherService.deleteTeacher(id);
  }
  /**
   * �޸Ľ�ʦ��Ϣ
   * @param req
   * @param resp
   */
  public void update(HttpServletRequest req, HttpServletResponse resp)
  {
	  //��֤����
	  String[] mustParam= {"id"};
	  V.valid(req, mustParam);
	  //��������
	  String[] params= {"tel","password","real_name","title","gender","email","degree","experience","id"};
      Teacher teacher=V.entity(req, Teacher.class, params);
      teacherService.updateTeacher(teacher);
  }
}
