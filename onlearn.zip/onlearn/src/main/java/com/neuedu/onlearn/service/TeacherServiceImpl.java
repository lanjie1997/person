package com.neuedu.onlearn.service;

import org.apache.ibatis.session.SqlSession;

import com.neuedu.omlearn.exception.InvaildParamException;
import com.neuedu.omlearn.util.D;
import com.neuedu.omlearn.util.E;
import com.neuedu.omlearn.util.Global;
import com.neuedu.omlearn.util.Md5Util;
import com.neuedu.onlearn.mapper.TeacherMapper;
import com.neuedu.onlearn.po.Teacher;

public class TeacherServiceImpl implements TeacherService {
   private TeacherMapper teacherMapper;
  
   public TeacherServiceImpl()
   {
	   SqlSession session = D.getConn();
	   teacherMapper =session.getMapper(TeacherMapper.class);
   }
   
   /**
    * �û���¼
    */
	public Teacher login(String username,String password) 
   {
		Teacher teacher=teacherMapper.findTeacherByTel(username);
		if(teacher == null)
		{
			throw new InvaildParamException(E.INVAILD_PARAM_ERROR_CODE,E.INVAILD_PARAM_ERROR_INFO);
		}
		//Md5����
		String encodePwd = Md5Util.encode(password);
		//���벻���
		if(!teacher.getPassword().equalsIgnoreCase(encodePwd)) 
		{
			throw new InvaildParamException(E.USER_PARAM_ERROR_CODE,E.USER_PARAM_ERROR_INFO);
		}
			
		return teacher;
   }

/**
 * ���ӽ�ʦ��Ϣ
 */
public void addTeacher(Teacher teacher) {
	teacher.setRole(Global.ROLE_TEACHER);
	String encodePwd =Md5Util.encode(teacher.getPassword());
	teacher.setPassword(encodePwd);
	teacherMapper.addTeacher(teacher);
}
/**
 * ɾ����ʦ���߼�ɾ��)
 */
public void deteleTeacher(Integer id)
{
	Teacher existTeacher=teacherMapper.findTeacherById(id);
	if(existTeacher==null)
	{
		throw new InvaildParamException(E.SELF_DEFINE_ERROR_CODE,"���û�������");
	}
	Teacher teacher=new Teacher();
	teacher.setId(id);
	teacher.setStatus(Global.USER_STATUS_OFF);
	teacherMapper.updateTeacher(teacher);
}
public void deleteTeacher(Integer id) {
	// TODO Auto-generated method stub
	
}
/**
 * �޸Ľ�ʦ��Ϣ
 */
public void updateTeacher(Teacher teacher)
{
	Teacher existTeacher=teacherMapper.findTeacherById(teacher.getId());
	if(existTeacher==null)
	{
		throw new InvaildParamException(E.SELF_DEFINE_ERROR_CODE,"���û�������");
	}
	
	teacherMapper.updateTeacher(teacher);
	
}




}
