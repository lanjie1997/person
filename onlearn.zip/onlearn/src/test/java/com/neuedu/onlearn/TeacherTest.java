package com.neuedu.onlearn;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.neuedu.omlearn.util.D;
import com.neuedu.onlearn.mapper.TeacherMapper;
import com.neuedu.onlearn.po.Teacher;


public class TeacherTest {
	
//	@Test
//   public void testJackSon() throws IOException
//   {
//	   
//	   ObjectMapper objMapper = new ObjectMapper();
//	   ApiResult apiRs=new ApiResult();
//	   apiRs.setCode(200);
//	   apiRs.setMsg("success");
//	   //java ����ת��Ϊjson
//	   String rs=objMapper.writeValueAsString(apiRs);
//	   System.out.println(rs);
//	   
//	   //jsonת��Ϊjava����
//	   ApiResult src= objMapper.readValue(rs, ApiResult.class);
//	   System.out.println(src);
//   }
   
	
	@Test
	public void testSelect()
	{
		SqlSession session =D.getConn();
		TeacherMapper tMapper = session.getMapper(TeacherMapper.class);
		Teacher teacher = tMapper.findTeacherByTel("1550360");
		System.out.println(teacher);
	}
}
