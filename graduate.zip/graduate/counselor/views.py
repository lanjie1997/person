from django.shortcuts import render
from django.contrib import auth
from django.http import  HttpResponse,HttpResponseRedirect
from django.contrib import messages
from django import forms
from .models import *
import json
# Create your views here.

class UserForm(forms.Form):
    username = forms.CharField(label='用户名')
    password = forms.CharField(label='密   码', widget=forms.PasswordInput())

def login(request):
    #判断是否已经登陆
    if request.session.get('is_login',None):
        return HttpResponseRedirect('/index/')
    #POST方法
    if request.method == 'POST':
        ##获取表单信息
        uf = UserForm(request.POST)
        if uf.is_valid():
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            user = Teacher.objects.get(teacher_username=username)
            #用户存在
            if user:
                #账号密码正确的情况
                passwd = Teacher.objects.filter(teacher_username=username, teacher_password=password)
                if passwd:
                    request.session['is_login'] = True
                    request.session['user_id'] = user.teacher_id
                    request.session['user_name'] = user.teacher_name
                    return HttpResponseRedirect('/index/')
                #账号密码不正确的情况
                else:
                    return HttpResponse('请检查密码是否正确!')
            #用户不存在
            elif len(user) == 0:
                return HttpResponse ('用户不存在！')
    else:
        uf = UserForm()
    return render(request,'login.html', {'uf': uf})

def index(request):
    if request.method == 'GET':
        students = Student.objects.all()
        return render(request, 'index.html', {'students': students})
    if request.method == 'POST':
        #创建一个字典
        conditions = {}
        #获取表单中各输入框的值，如果不为空，则以键值对的形式加入字典
        if request.POST.get('student_name__contains', "") != '':
            conditions['student_name__contains'] = request.POST.get('student_name__contains')
        if request.POST.get('student_age',"") != "":
            conditions['student_age__exact'] = request.POST.get('student_age__exact')
        if request.POST.get('student_class__contains', "") != "":
            conditions['student_class__contains'] = request.POST.get('student_class__contains')
        if request.POST.get('student_room__contains', "") != "":
            conditions['student_room__contains'] = request.POST.get('student_room__contains')
        if request.POST.get('student_parentname__contains', "") != '':
            conditions['student_parentname__contains'] = request.POST.get('student_parentname')
        if request.POST.get('student_sex__contains', "") != "":
            conditions['student_sex__contains'] = request.POST.get('student_sex')
        #创建一个列表
        sds = []
        #组合查询
        for student in Student.objects.filter(**conditions):
            x = {}
            x['student_id'] = student.student_id
            x['student_name'] = student.student_name
            x['student_age'] = student.student_age
            x['student_sex'] = student.student_sex
            x['student_class'] = student.student_class
            x['student_room'] = student.student_room
            x['student_phone'] = student.student_phone
            x['student_parentname'] = student.student_parentname
            x['student_parentphone'] = student.student_parentphone
            #查到数据加入列表
            sds.append(x)
        return render(request, 'index.html', {'students': sds})
def studentInfo(request):
    if request.method == 'GET':
        students = Student.objects.all()
        return render(request, 'studentInfo.html', {"students": students})

def leave(request):
    if request.method == 'GET':
        leaves=Leave.objects.all()
        return render(request, "leave.html", {"leaves": leaves})
    if request.method == 'POST':
        a = Leave(leave_studentname=request.POST.get('leave_studentname'),leave_time=request.POST.get('leave_time'),leave_reason=request.POST.get('leave_reason'),leave_options=request.POST.get('leave_options'))
        a.save()
        return HttpResponseRedirect('/index/')
def punish(request):
    if request.method == "GET":
        punishes = Punish.objects.all()
        return render(request , 'punish.html', {"punishes": punishes})
    if request.method == "POST":
        a = Punish(punish_studentname=request.POST.get('punish_studentname'),punish_time=request.POST.get('punish_time'),punish_reason=request.POST.get('punish_reason'),punish_context=request.POST.get('punish_context'))
        a.save()
        return HttpResponseRedirect('/index/')
def award(request):
    if request.method == "GET":
        awards = Award.objects.all()
        return render(request, 'award.html', {'awards': awards})
    if request.method == "POST":
        a = Award(award_studentname=request.POST.get('award_studentname'),award_time=request.POST.get('award_time'),award_something=request.POST.get('award_something'),award_reason=request.POST.get('award_reason'))
        a.save()
        return HttpResponseRedirect('/index/')
def talk(request):
    if request.method == "GET":
        talks = Talk.objects.all()
        return render(request, 'talk.html', {'talks': talks})
    if request.method == "POST":
        a = Talk(talk_studentname=request.POST.get('talk_studentname'),talk_time=request.POST.get('talk_time'),talk_context=request.POST.get('talk_context'))
        a.save()
        return HttpResponseRedirect('/index/')
def recordelse(request):
    if request.method == 'GET':
        elses =Else.objects.all()
        return render(request, 'elserecord.html', {'elses': elses})
    if request.method == 'POST':
        a = Else(else_studentname=request.POST.get('else_studentname'),else_time=request.POST.get('else_time'),else_context=request.POST.get('else_context'))
        a.save()
        return HttpResponseRedirect('/index/')
def course(request):
    return render(request , 'course.html')
def logout(request):
    if not request.session.get('is_login', None):
        # 如果本来就未登录，也就没有登出一说
        return HttpResponseRedirect("/login/")
    request.session.flush()
    return HttpResponseRedirect("/login/")





def delelse(request):
    resp = json.loads(request.body)
    else_id = resp['else_id']
    a = Else.objects.filter(else_id=else_id)
    a.delete()
    return HttpResponse(request,'Success')
def delaward(request):
    resp =json.loads(request.body)
    award_id = resp['award_id']
    a = Award.objects.filter(award_id=award_id)
    a.delete()
    return HttpResponse(request,"Success")
def delleave(request):
    resp = json.loads(request.body)
    leave_id = resp['leave_id']
    a = Leave.objects.filter(leave_id=leave_id)
    a.delete()
    return HttpResponse(request, "Success")
def delpunish(request):
    resp = json.loads(request.body)
    punish_id = resp['punish_id']
    a = Punish.objects.filter(punish_id=punish_id)
    a.delete()
    return HttpResponse(request, "Success")
def deltalk(request):
    resp = json.loads(request.body)
    talk_id = resp['talk_id']
    a = Talk.objects.filter(talk_id=talk_id)
    a.delete()
    return HttpResponse(request, "Success")
def showcourse(request):
    # if request.method == 'POST':
    #     showclass = request.POST.get('class')
        # a = {}
        # a['i'] = showclass
    return render(request,'showcourse.html')
def showgrade(request):
    return render(request,'showgrade.html')
def showstudent(request):
    result = json.loads(request.body.decode())
    # 创建一个字典
    conditions = {}
    # 获取表单中各输入框的值，如果不为空，则以键值对的形式加入字典
    if result['student_name'] != '':
        conditions['student_name__contains'] = result['student_name']
    if result['student_age'] != "":
        conditions['student_age__exact'] = result['student_age']
    if result['student_class'] != "":
        conditions['student_class__contains'] = result['student_class']
    if result['student_room'] != "":
        conditions['student_room__contains'] = result['student_room']
    if result['student_parentname'] != '':
        conditions['student_parentname__contains'] = result['student_parentname']
    if result['student_sex'] != "":
        conditions['student_sex__contains'] = result['student_sex']
    # 创建一个列表
    sds = []
    # 组合查询
    for student in Student.objects.filter(**conditions):
        x = {}
        x['student_id'] = student.student_id
        x['student_name'] = student.student_name
        x['student_age'] = student.student_age
        x['student_sex'] = student.student_sex
        x['student_class'] = student.student_class
        x['student_room'] = student.student_room
        x['student_phone'] = student.student_phone
        x['student_parentname'] = student.student_parentname
        x['student_parentphone'] = student.student_parentphone
        # 查到数据加入列表
        sds.append(x)
    return render(request, 'showstudent.html', {'students': sds})
