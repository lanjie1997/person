from django.apps import AppConfig


class CounselorConfig(AppConfig):
    name = 'counselor'
