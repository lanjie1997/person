from django.db import models

# Create your models here.
class Teacher(models.Model):
    teacher_id = models.AutoField(primary_key=True)
    teacher_name = models.CharField(max_length=20, null=False)
    teacher_sex = models.CharField(max_length=10, null=False)
    teacher_username=models.CharField(max_length=15, null=False)
    teacher_password =models.CharField(max_length=20, null=False)
    teacher_age = models.IntegerField(null=False)
    teacher_class = models.CharField(max_length=10, null=False)
    def __str__(self):
        return self.teacher_name
    class Meta:
        verbose_name_plural = '教师'
        managed = True

class Student(models.Model):
    student_id = models.AutoField(primary_key=True)
    student_name = models.CharField(max_length=20, null=False)
    student_age = models.IntegerField(null=False)
    student_sex = models.CharField(max_length=10, null=False)
    student_class = models.CharField(max_length=15, null=False)
    student_room = models.CharField(max_length=30, null=False)
    student_parentname = models.CharField(max_length=20, null=False)
    student_phone = models.CharField(max_length=11, null=False)
    student_parentphone = models.CharField(max_length=11, null=False)
    def __str__(self):
        return self.student_name
    class Meta:
        verbose_name_plural = '学生'
        managed = True

class Talk(models.Model):
    talk_id = models.AutoField(primary_key=True)
    talk_time = models.CharField(max_length=50, null=False)
    talk_studentname = models.CharField(max_length=20, null=False)
    talk_context = models.CharField(max_length=1000, null=False)
    def __str__(self):
        return self.talk_studentname
    class Meta:
        verbose_name_plural = "谈话记录"
        managed = True


class Leave(models.Model):
    leave_id = models.AutoField(primary_key=True)
    leave_studentname = models.CharField(max_length=20, null=False)
    leave_time = models.CharField(max_length=50, null=False)
    leave_reason = models.CharField(max_length=50, null=False)
    leave_options = models.CharField(max_length=20, null=False)
    def __str__(self):
        return self.leave_studentname
    class Meta:
        verbose_name_plural = "请假记录"
        managed = True

class Award(models.Model):
    award_id = models.AutoField(primary_key=True)
    award_studentname = models.CharField(max_length=20, null=False)
    award_time = models.CharField(max_length=30, null=False)
    award_something =models.CharField(max_length=20, null=False)
    award_reason =models.CharField(max_length=50, null=False)
    def __str__(self):
        return self.award_studentname
    class Meta:
        verbose_name_plural = "奖励记录"
        managed = True

class Punish(models.Model):
    punish_id = models.AutoField(primary_key=True)
    punish_studentname = models.CharField(max_length=20, null=False)
    punish_time = models.CharField(max_length=30, null=False)
    punish_context = models.CharField(max_length=50, null=False)
    punish_reason = models.CharField(max_length=50, null=False)
    def __str__(self):
        return self.punish_studentname
    class Meta:
        verbose_name_plural = '处罚记录'
        managed = True

class Else(models.Model):
    else_id = models.AutoField(primary_key=True)
    else_studentname = models.CharField(max_length=20, null=False)
    else_time = models.CharField(max_length=30, null=False)
    else_context = models.CharField(max_length=50, null=False)
    def __str__(self):
        return self.else_studentname
    class Meta:
        verbose_name_plural = '其他记录'
        managed = True