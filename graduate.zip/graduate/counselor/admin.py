from django.contrib import admin
from counselor.models import *
class TeacherAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['teacher_id' , 'teacher_name', 'teacher_sex', 'teacher_class', 'teacher_age', 'teacher_username', 'teacher_password' ]
    # 用于过滤的字段
    list_filter = ['teacher_name', 'teacher_sex']
    # 用于查询的字段
    search_fields = ['teacher_name', 'teacher_age','teacher_class']

class StudentAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['student_id', 'student_name', 'student_sex', 'student_class', 'student_room', 'student_parentname', 'student_phone', 'student_parentphone']
    #用于过滤的字段
    list_filter = ['student_name', 'student_class', 'student_room', 'student_sex']
    #用于查询的字段
    search_fields = ['student_name', 'student_class', 'student_room']

class TalkAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = [ 'talk_studentname', 'talk_time', 'talk_context']
    #用于过滤的字段
    list_filter = ['talk_studentname']
    #用于查询的字段
    search_fields = ['talk_studentname','talk_time']

class AwardAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['award_studentname', 'award_time', 'award_something', 'award_reason']
    #用于过滤的字段
    list_filter = ['award_studentname', 'award_time', 'award_something']
    #用于查询的字段
    search_fields = ['award_studentname', 'award_time', 'award_something']
class LeaveAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['leave_studentname' , 'leave_time', 'leave_reason', 'leave_options']
    #用于过滤的字段
    list_filter = ['leave_studentname' , 'leave_time', 'leave_options']
    #用于查询的字段
    search_fields = ['leave_studentname', 'leave_time', 'leave_reason', 'leave_options']
class PunishAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['punish_studentname', 'punish_reason', 'punish_time', 'punish_context']
    #用于过滤的字段
    list_filter = ['punish_studentname', 'punish_time', 'punish_reason']
    #用于查询的字段
    search_fields = ['punish_studentname', 'punish_reason', 'punish_time']
class RecordelseAdmin(admin.ModelAdmin):
    #显示的字段
    list_display = ['else_studentname', 'else_time', 'else_context']
    #用于过滤的字段
    list_filter = ['else_studentname', 'else_time']
    #用于查询的字段
    search_fields = ['else_studentname', 'else_context']
admin.site.register(Teacher, TeacherAdmin)
admin.site.register(Student, StudentAdmin)
admin.site.register(Talk, TalkAdmin)
admin.site.register(Award, AwardAdmin)
admin.site.register(Leave, LeaveAdmin)
admin.site.register(Punish, PunishAdmin)
admin.site.register(Else, RecordelseAdmin)